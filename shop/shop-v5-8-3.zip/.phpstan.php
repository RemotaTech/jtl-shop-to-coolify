<?php

declare(strict_types=1);

require __DIR__ . '/includes/config.JTL-Shop.ini.php';
require __DIR__ . '/includes/defines.php';
require __DIR__ . '/includes/autoload.php';
require __DIR__ . '/dbeS/functions.php';

const FREIDEFINIERBARER_FEHLER          = 1;
const SHOP_ERWEITERUNG_BRANDFREE        = 1;
const CONSISTENT_GROSS_PRICES           = true;
const SHOP_ERWEITERUNG_UPLOADS          = 8031;
const SHOP_ERWEITERUNG_AUSWAHLASSISTENT = 8031;
const SHOP_ERWEITERUNG_DOWNLOADS        = 8031;
const SHOP_ERWEITERUNG_KONFIGURATOR     = 8031;
const TIDEWAYS_XHPROF_FLAGS_CPU         = 1;
const TIDEWAYS_XHPROF_FLAGS_MEMORY      = 1;
const TIDEWAYS_FLAGS_CPU                = 1;
const TIDEWAYS_FLAGS_MEMORY             = 1;
const TIDEWAYS_FLAGS_NO_SPANS           = 1;

if (!function_exists('__')) {
    function __(string $original, ...$args): string
    {
        return '';
    }
}

if (!function_exists('tideways_disable')) {
    function tideways_disable(): array
    {
        return [];
    }
}

if (!function_exists('tideways_xhprof_disable')) {
    function tideways_xhprof_disable(): array
    {
        return [];
    }
}

if (!class_exists('XHProfRuns_Default')) {
    class XHProfRuns_Default
    {
        public function __construct(private string $dir)
        {

        }

        /**
         * @param array<mixed> $data
         */
        public function save_run(array $data, string $name = '', string $namespace = ''): string
        {
            return uniqid('', true);
        }
    }
}
