# JTL-Shop

|**JTL-Shop** is an open source shop software designed for use with JTL-Wawi. |
|:-----------------:|

## System Requirements

**Webserver**
* Apache Version 2.2 or 2.4
	* mod_rewrite module activated
	* .htaccess support (allowed to override options)
* nginx
  
**Database** 
* MySQL >=8.4.0
* MariaDB >=10.11.0, <=12.0.2

**PHP**
* PHP >=8.3
* PHP-Modules:
    * [BCMath (ext-bcmath)](https://www.php.net/manual/en/book.bc.php)
    * [Curl (ext-curl)](https://php.net/manual/en/book.curl.php)
    * [DOM (ext-dom)](https://www.php.net/manual/en/intro.dom.php)
    * [File Information (ext-fileinfo)](https://www.php.net/manual/en/book.fileinfo.php)
    * [FTP (ext-ftp)](https://www.php.net/manual/en/book.ftp.php)
    * [ImageMagick + Imagick (ext-gd)](https://php.net/manual/en/book.imagick.php)
    * [Iconv (ext-iconv)](https://php.net/manual/en/book.iconv.php)
    * [Intl (ext-intl)](https://www.php.net/manual/de/book.intl.php)
    * [JavaScript Object Notation (ext-json)](https://www.php.net/manual/en/book.json.php)
    * [libxml (ext-libxml)](https://www.php.net/manual/en/book.libxml.php)
    * [MBString (ext-mbstring)](https://php.net/manual/en/book.mbstring.php)
    * [PDO (MySQL) (ext-pdo)](https://php.net/manual/en/book.pdo.php)
    * [SimpleXML (ext-simplexml)](https://php.net/manual/en/book.simplexml.php)
    * [SOAP (ext-soap)](https://www.php.net/manual/en/book.soap.php)
    * [XML Parser (ext-xml)](https://www.php.net/manual/en/book.xml.php)
    * [Zip (ext-zip)](https://www.php.net/manual/en/book.zip.php)
    * [Zlib Compression (ext-zlib)](https://www.php.net/manual/en/book.zlib.php)
	* Optional: [IonCube Loader](https://www.ioncube.com/loaders.php) for some third-party plug-ins
* PHP Settings
	* `max_execution_time` >= 120s
	* `memory_limit` >= 128MB
	* `upload_max_filesize` >= 8MB
	* `allow_url_fopen` activated

## Software boundaries
* See [Software boundaries and limits](https://jtl-url.de/limits) for details

## License 
* MIT License - see [LICENSE.md](LICENSE.md)

## Changelog
* See [issues.jtl-software.de](https://issues.jtl-software.de/issues?project=JTL-Shop) or review commits in [Gitlab](https://gitlab.com/jtl-software/jtl-shop/core) for the latest changes

## Third party libraries
* [Smarty](https://www.smarty.net/) - LGPL
* brick/math - MIT
* carbonphp/carbon-doctrine-types - MIT
* chamilo/pclzip - LGPL-2.1
* cocur/slugify - MIT
* composer/semver - MIT
* doctrine/inflector - MIT
* dompdf/dompdf - LGPL-2.1
* dompdf/php-font-lib - LGPL-2.1-or-later
* dompdf/php-svg-lib - LGPL-3.0-or-later
* erusev/parsedown - MIT
* ezyang/htmlpurifier - LGPL-2.1-or-later
* fakerphp/faker - MIT
* gettext/gettext - MIT
* gettext/languages - MIT
* gettext/translator - MIT
* google/protobuf - BSD-3-Clause
* greew/oauth2-azure-provider - GPL-3.0-or-later
* guzzlehttp/guzzle - MIT
* guzzlehttp/promises - MIT
* guzzlehttp/psr7 - MIT
* ifsnop/mysqldump-php - GPL-3.0-or-later
* illuminate/collections - MIT
* illuminate/conditionable - MIT
* illuminate/container - MIT
* illuminate/contracts - MIT
* illuminate/macroable - MIT
* illuminate/reflection - MIT
* illuminate/support - MIT
* intervention/gif - MIT
* intervention/httpauth - MIT
* intervention/image - MIT
* jaybizzle/crawler-detect - MIT
* jdorn/sql-formatter - MIT
* jtl/minify - BSD-3-Clause
* jtlshop/phpquery - MIT
* jtlshop/scc - MIT
* jtlshop/sccbs3 - MIT
* jtlshop/semver - MIT
* jtlshop/shop5-systemcheck - MIT
* jtlshop/smarty4 - LGPL-3.0
* jtlshop/xtea - MIT
* laminas/laminas-diactoros - BSD-3-Clause
* laminas/laminas-httphandlerrunner - BSD-3-Clause
* laravel/serializable-closure - MIT
* league/flysystem - MIT
* league/flysystem-ftp - MIT
* league/flysystem-local - MIT
* league/flysystem-sftp-v3 - MIT
* league/flysystem-ziparchive - MIT
* league/fractal - MIT
* league/mime-type-detection - MIT
* league/oauth2-client - MIT
* league/oauth2-google - MIT
* league/route - MIT
* league/uri - MIT
* league/uri-interfaces - MIT
* lstrojny/functional-php - MIT
* marcusschwarz/lesserphp - MIT, GPL-3.0
* masterminds/html5 - MIT
* mobiledetect/mobiledetectlib - MIT
* monolog/monolog - MIT
* mrclay/jsmin-php - MIT
* mrclay/props-dic - MIT
* myclabs/php-enum - MIT
* nesbot/carbon - MIT
* nikic/fast-route - BSD-3-Clause
* nyholm/psr7-server - MIT
* open-telemetry/api - Apache-2.0
* open-telemetry/context - Apache-2.0
* open-telemetry/exporter-otlp - Apache-2.0
* open-telemetry/gen-otlp-protobuf - Apache-2.0
* open-telemetry/sdk - Apache-2.0
* open-telemetry/sem-conv - Apache-2.0
* paragonie/constant_time_encoding - MIT
* paragonie/random_compat - MIT
* php-debugbar/php-debugbar - MIT
* php81_bc/strftime - MIT
* phpmailer/phpmailer - LGPL-2.1-only
* phpmyadmin/sql-parser - GPL-2.0-or-later
* phpseclib/phpseclib - MIT
* pimple/pimple - MIT
* psr/clock - MIT
* psr/container - MIT
* psr/http-client - MIT
* psr/http-factory - MIT
* psr/http-message - MIT
* psr/http-server-handler - MIT
* psr/http-server-middleware - MIT
* psr/log - MIT
* psr/simple-cache - MIT
* rakit/validation - MIT
* ralouphie/getallheaders - MIT
* ramsey/collection - MIT
* ramsey/uuid - MIT
* sabberworm/php-css-parser - MIT
* scssphp/scssphp - MIT
* scssphp/source-span - MIT
* sebastian/diff - BSD-3-Clause
* smarty/smarty - LGPL-3.0
* studio-42/elfinder - BSD-3-Clause
* symfony/clock - MIT
* symfony/console - MIT
* symfony/deprecation-contracts - MIT
* symfony/filesystem - MIT
* symfony/finder - MIT
* symfony/polyfill-ctype - MIT
* symfony/polyfill-intl-grapheme - MIT
* symfony/polyfill-intl-normalizer - MIT
* symfony/polyfill-php82 - MIT
* symfony/polyfill-php83 - MIT
* symfony/polyfill-php84 - MIT
* symfony/polyfill-php85 - MIT
* symfony/process - MIT
* symfony/service-contracts - MIT
* symfony/string - MIT
* symfony/translation - MIT
* symfony/translation-contracts - MIT
* symfony/var-dumper - MIT
* thecodingmachine/safe - MIT
* tubalmartin/cssmin - BSD-3-Clause
* voku/portable-ascii - MIT
* wikimedia/less.php - Apache-2.0

### Frontend libraries
* jQuery + jQuery UI + various jQuery Scripts - MIT
* Bootstrap + Bootstrap-Scripts - MIT
* FileInput - BSD
* typeAhead - MIT
* LESS Leaner CSS - Apache v2 License
* [slick](https://github.com/kenwheeler/slick/) - MIT

## Contributing

If you want to participate in the development of JTL-Shop,  
you can do it in the following way:

* first create your own *fork* of this repository
* then create a *branch* in your own *fork*
* finally make a merge request for that *branch* in the *upstream* of your *fork*

Please DO NOT create a merge request of your own master branch!

A short description of the procedure can be found here: 
[contributing](https://docs.jtl-shop.de/de/latest/shop_programming_tips/contributing.html)

## Related Links

* [JTL](https://www.jtl-software.de/) - JTL-Software Homepage
* [JTL Userguide](https://guide.jtl-software.de/) - Userguide
* [JTL Developer Documentation](https://docs.jtl-shop.de/) - Developer Docs
* [JTL Community](https://forum.jtl-software.de/) - JTL-Forum 
* [JTL Shop-Entwicklung](https://gitlab.com/jtl-software/jtl-shop/core) - GitLab Repository
* [JTL Shop-Builds](https://build.jtl-shop.de/) - Ready-to-use zip archives 
