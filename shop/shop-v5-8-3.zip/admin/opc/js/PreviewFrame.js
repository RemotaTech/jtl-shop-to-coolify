import {installGuiElements} from "./utils.js";

export class PreviewFrame
{
    constructor(iframe)
    {
        this.iframe = iframe;
    }

    init()
    {
        installGuiElements(this, [
            'previewPanel',
            'previewFrame',
        ]);
    }

    async showPreview(pageFullUrl, draftData)
    {
        this.previewFrame.contents().find('body').html('');
        this.previewPanel.show();

        await new Promise(res => {
            this.previewFrame.off('load').on('load', res);
            window.previewPageDataInput.value = draftData;
            window.previewForm.action = pageFullUrl;
            window.previewForm.submit();
        });

        let previewJq     = this.previewFrame[0].contentWindow.$;
        let uidsWithForms = [];

        for (let portlet of previewJq('[data-portlet-with-forms=true]')) {
            uidsWithForms.push(portlet.dataset.uid);
        }

        this.iframe.setPortletUidsContainingForms(uidsWithForms);
    }
}
