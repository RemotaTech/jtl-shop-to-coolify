{includeMailTemplate template=header type=html}

<p>Hallo {$EmailChanged->cName},<br>
die E-Mail-Adresse für Ihr Kundenkonto bei {$EmailChanged->shopName} wurde geändert.</p>

<p>Details:<br>
<b>Zeit:</b> {$EmailChanged->timestamp|date_format:'%d.%m.%Y'}, um
{$EmailChanged->timestamp|date_format:'%H:%M:%S'}<br>
<b>IP-Adresse:</b> {$EmailChanged->ipv4}</p>

<p><b>Ihnen kommt diese Aktivität bekannt vor?</b><br>
Sie können diese E-Mail einfach ignorieren und müssen nichts weiter tun.</p>

<p><b>Sie haben die E-Mail-Adresse nicht geändert?</b><br>
Bitte kontaktieren Sie uns schnellstmöglich und melden das Problem. Gemeinsam finden wir eine Lösung.</p>

<p>Ihr Team von {$EmailChanged->shopName}</p>

{includeMailTemplate template=footer type=html}