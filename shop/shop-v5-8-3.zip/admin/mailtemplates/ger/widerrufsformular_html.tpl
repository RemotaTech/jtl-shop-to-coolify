{includeMailTemplate template=header type=html}

<p>Guten Tag {$Withdrawal->cName},</p>

<p>wir haben Ihren Widerruf zu der Bestellung <strong>{$Withdrawal->cOrderNumber}</strong>
    am {$Withdrawal->dSubmitted} erhalten.</p>

<p><strong>Übersicht Ihrer Angaben:</strong></p>
<ul>
    <li>Ihre E-Mail-Adresse: {$Withdrawal->cEmail}</li>
    <li>Ihr Kommentar: {$Withdrawal->cComment|nl2br}</li>
</ul>

<p>Es tut uns leid, dass Sie mit Ihrer Bestellung unzufrieden waren.
    Wir werden Ihren Widerruf schnellstmöglich bearbeiten und Sie diesbezüglich kontaktieren.</p>

{includeMailTemplate template=footer type=html}