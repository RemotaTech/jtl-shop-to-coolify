{includeMailTemplate template=header type=plain}

Hallo {$EmailChanged->cName},
die E-Mail-Adresse für Ihr Kundenkonto bei {$EmailChanged->shopName} wurde geändert.

Details:
Zeit: {$EmailChanged->timestamp|date_format:'%d.%m.%Y'}, um
{$EmailChanged->timestamp|date_format:'%H:%M:%S'}
IP-Adresse: {$EmailChanged->ipv4}

Ihnen kommt diese Aktivität bekannt vor?
Sie können diese E-Mail einfach ignorieren und müssen nichts weiter tun.

Sie haben die E-Mail-Adresse nicht geändert?
Bitte kontaktieren Sie uns schnellstmöglich und melden das Problem. Gemeinsam finden wir eine Lösung.

Ihr Team von {$EmailChanged->shopName}

{includeMailTemplate template=footer type=plain}