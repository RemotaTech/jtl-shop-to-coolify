{includeMailTemplate template=header type=html}

<p>Hallo {$PasswordChanged->cName},<br>
das Passwort für Ihr Kundenkonto bei {$PasswordChanged->shopName} wurde geändert.</p>

<p>Details:<br>
<b>Zeit:</b> {$PasswordChanged->timestamp|date_format:'%d.%m.%Y'}, um
{$PasswordChanged->timestamp|date_format:'%H:%M:%S'}<br>
<b>IP-Adresse:</b> {$PasswordChanged->ipv4}</p>

<p><b>Ihnen kommt diese Aktivität bekannt vor?</b><br>
Sie können diese E-Mail einfach ignorieren und müssen nichts weiter tun.</p>

<p><b>Sie haben das Passwort nicht geändert?</b><br>
Bitte setzen Sie Ihr Passwort schnellstmöglich zurück.<br><br>
Wir empfehlen außerdem, dass Sie die 2-Faktor-Authentifizierung für Ihr Kundenkonto aktivieren. Loggen
Sie sich dazu in Ihr Kundenkonto ein und klicken Sie im Bereich "Meine persönlichen Daten > 2-Faktor-Authentifizierung"
auf das Stift-Symbol.</p>

<p>Bei Fragen helfen wir Ihnen gerne weiter.</p>
<p>Ihr Team von {$PasswordChanged->shopName}</p>

{includeMailTemplate template=footer type=html}