{includeMailTemplate template=header type=plain}

Guten Tag {$Withdrawal->cName},

wir haben Ihren Widerruf zu der Bestellung {$Withdrawal->cOrderNumber} am {$Withdrawal->dSubmitted} erhalten.

Übersicht Ihrer Angaben:
Ihre E-Mail-Adresse: {$Withdrawal->cEmail}
Ihr Kommentar: {$Withdrawal->cComment}

Es tut uns leid, dass Sie mit Ihrer Bestellung unzufrieden waren.
Wir werden Ihren Widerruf schnellstmöglich bearbeiten und Sie diesbezüglich kontaktieren.

{includeMailTemplate template=footer type=plain}