{includeMailTemplate template=header type=plain}

Hallo {$PasswordChanged->cName},
das Passwort für Ihr Kundenkonto bei {$PasswordChanged->shopName} wurde geändert.

Details:
Zeit: {$PasswordChanged->timestamp|date_format:'%d.%m.%Y'}, um
{$PasswordChanged->timestamp|date_format:'%H:%M:%S'}
IP-Adresse: {$PasswordChanged->ipv4}

Ihnen kommt diese Aktivität bekannt vor?
Sie können diese E-Mail einfach ignorieren und müssen nichts weiter tun.

Sie haben das Passwort nicht geändert?
Bitte setzen Sie Ihr Passwort schnellstmöglich zurück.

Wir empfehlen außerdem, dass Sie die 2-Faktor-Authentifizierung für Ihr Kundenkonto aktivieren. Loggen Sie sich dazu in
Ihr Kundenkonto ein und klicken Sie im Bereich 'Meine persönlichen Daten > 2-Faktor-Authentifizierung' auf
das Stift-Symbol.

Bei Fragen helfen wir Ihnen gerne weiter.
Ihr Team von {$PasswordChanged->shopName}

{includeMailTemplate template=footer type=plain}