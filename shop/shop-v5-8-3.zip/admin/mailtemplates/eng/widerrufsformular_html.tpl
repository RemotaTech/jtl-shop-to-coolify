{includeMailTemplate template=header type=html}

<p>Hello {$Withdrawal->cName},</p>

<p>We have received your withdrawal for the order <strong>{$Withdrawal->cOrderNumber}</strong>
    on {$Withdrawal->dSubmitted}.</p>

<p><strong>Overview of your information:</strong></p>
<ul>
    <li>Your email address: {$Withdrawal->cEmail}</li>
    <li>Your comment: {$Withdrawal->cComment|nl2br}</li>
</ul>

<p>We are sorry to hear that you were unhappy with your order.
    We will process your withdrawal as soon as possible and contact you in this regard.</p>

{includeMailTemplate template=footer type=html}