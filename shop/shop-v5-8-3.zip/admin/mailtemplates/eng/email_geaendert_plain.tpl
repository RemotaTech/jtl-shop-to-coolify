{includeMailTemplate template=header type=plain}

Hello {$EmailChanged->cName},
The email address for your customer account at {$EmailChanged->shopName} has been changed.

Details:
Time: {$EmailChanged->timestamp|date_format:'%m-%d-%Y'}, at
{$EmailChanged->timestamp|date_format:'%H:%M:%S'}
IP address: {$EmailChanged->ipv4}

Did you change the email address?
You can simply ignore this email and you do not need to do anything else.

Did somebody else change the email address?
Please contact us as soon as possible to let us know about this issue. Together we will find a solution.

Your team at {$EmailChanged->shopName}

{includeMailTemplate template=footer type=plain}