{includeMailTemplate template=header type=html}

<p>Hello {$EmailChanged->cName},<br>
The email address for your customer account at {$EmailChanged->shopName} has been changed.</p>

<p>Details:<br>
<b>Time:</b> {$EmailChanged->timestamp|date_format:'%m-%d-%Y'}, at
{$EmailChanged->timestamp|date_format:'%H:%M:%S'}<br>
<b>IP address:</b> {$EmailChanged->ipv4}</p>

<p><b>Did you change the email address?</b><br>
You can simply ignore this email and you do not need to do anything else.</p>

<p><b>Did somebody else change the email address?</b><br>
Please contact us as soon as possible to let us know about this issue. Together we will find a solution.</p>

<p>Your team at {$EmailChanged->shopName}</p>

{includeMailTemplate template=footer type=html}