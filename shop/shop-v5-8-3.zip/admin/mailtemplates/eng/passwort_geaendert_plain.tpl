{includeMailTemplate template=header type=plain}

Hello {$PasswordChanged->cName},
the password for your customer account at {$PasswordChanged->shopName} has been changed.

Details:
Time: {$PasswordChanged->timestamp|date_format:'%m-%d-%Y'}, at
{$PasswordChanged->timestamp|date_format:'%H:%M:%S'}
IP address: {$PasswordChanged->ipv4}

Did you change the password?
You can simply ignore this email and you do not need to do anything else.

Did somebody else change the password?
Please reset your password as soon as possible.

We also recommend that you enable 2-factor authentication for your customer account.
To do this, log into your customer account and click on the pen icon in the
"My personal data > 2-Factor-Authentication" section.

If you have any questions, we are happy to help you.
Your team at {$PasswordChanged->shopName}

{includeMailTemplate template=footer type=plain}