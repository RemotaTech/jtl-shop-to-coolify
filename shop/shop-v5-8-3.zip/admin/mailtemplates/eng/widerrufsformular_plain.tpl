{includeMailTemplate template=header type=plain}

Hello {$Withdrawal->cName},

We have received your withdrawal for the order {$Withdrawal->cOrderNumber} on {$Withdrawal->dSubmitted}.

Overview of your information:
Your email address: {$Withdrawal->cEmail}
Your comment: {$Withdrawal->cComment}

We are sorry to hear that you were unhappy with your order.
We will process your withdrawal as soon as possible and contact you in this regard.

{includeMailTemplate template=footer type=plain}