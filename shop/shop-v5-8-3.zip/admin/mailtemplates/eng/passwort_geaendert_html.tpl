{includeMailTemplate template=header type=html}

<p>Hello {$PasswordChanged->cName},<br>
the password for your customer account at {$PasswordChanged->shopName} has been changed.</p>

<p>Details:<br>
<b>Time:</b> {$PasswordChanged->timestamp|date_format:'%m-%d-%Y'}, at
{$PasswordChanged->timestamp|date_format:'%H:%M:%S'}<br>
<b>IP address:</b> {$PasswordChanged->ipv4}</p>

<p><b>Did you change the password?</b><br>
You can simply ignore this email and you do not need to do anything else.</p>

<p><b>Did somebody else change the password?</b><br>
Please reset your password as soon as possible.<br><br>
We also recommend that you enable 2-factor authentication for your customer account. To do this, log into your
customer account and click on the pen icon in the "My personal data > 2-Factor-Authentication" section.</p>

<p>If you have any questions, we are happy to help you.</p>
<p>Your team at {$PasswordChanged->shopName}</p>

{includeMailTemplate template=footer type=html}