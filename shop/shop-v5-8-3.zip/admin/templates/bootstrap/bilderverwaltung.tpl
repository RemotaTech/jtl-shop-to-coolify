{include file='tpl_inc/header.tpl'}
{include file='tpl_inc/seite_header.tpl' cTitel=__('bilderverwaltung') cBeschreibung=__('bilderverwaltungDesc')
        cDokuURL=__('bilderverwaltungURL')}
<div id="content">
    <div class="card">
        <div class="card-body">
            {if isset($success)}
                <div class="alert alert-success"><i class="fal fa-info-circle"></i> {$success}</div>
            {/if}
            <div class="table-responsive">
                <table class="list table" id="cache-items" style="width: 100%">
                    <thead>
                    <tr>
                        <th class="text-left">{__('headlineTyp')}</th>
                        <th class="text-center">{__('headlineTotal')}</th>
                        <th class="text-center abbr">{__('headlineCache')}</th>
                        <th class="text-center">{__('faulty')}</th>
                        <th class="text-center" style="width:125px">{__('headlineSize')}</th>
                        <th class="text-center" style="width:200px">{__('actions')}</th>
                    </tr>
                    </thead>
                    <tbody>
                    {foreach $items as $item}
                        <tr data-type="{$item->type}">
                            <td class="item-name">{$item->name}</td>
                            <td class="text-center">
                                <span class="item-total">
                                  <i class="fa fa-spinner fa-spin"></i>
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="item-generated">
                                  <i class="fa fa-spinner fa-spin"></i>
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="item-corrupted"><i class="fa fa-spinner fa-spin"></i></span>
                            </td>
                            <td class="text-center item-total-size">
                                <i class="fa fa-spinner fa-spin"></i>
                            </td>
                            <td class="text-center action-buttons">
                                <a class="btn btn-outline-primary btn-sm mb-2" href="#" data-callback="flush"
                                   data-type="{$item->type}">
                                    <i class="fas fa-trash-alt"></i> {__('deleteCachedPics')}
                                </a>
                                <a class="btn btn-outline-primary btn-sm mb-2" href="#" data-callback="cleanup"
                                   data-type="{$item->type}">
                                    <i class="fas fa-trash"></i> {__('cleanup')}
                                </a>
                                <a class="btn btn-primary btn-sm" href="#" data-callback="generate"
                                   data-type="{$item->type}">
                                    <i class="fa fa-cog"></i> {__('generatePics')}
                                </a>
                            </td>
                        </tr>
                    {/foreach}
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="d-none" id="corrupted-images-wrap">
        <div class="content-header">
            <h1 class="content-header-headline top40">
                {__('currentCorruptedPics')}
            </h1>
            <div class="description">
                {sprintf(__('corruptedPicsNote'), $smarty.const.MAX_CORRUPTED_IMAGES)}
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <table class="list table table-condensed">
                    <thead>
                    <tr>
                        <th>{__('Type')}</th>
                        <th>{__('Image')}</th>
                        <th>{__('Identifier')}</th>
                    </tr>
                    </thead>
                    <tbody id="corrupted-images-tbody">
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    var lastResults = null,
        lastTick = null,
        running = false,
        imageStats = [],
        notify = null;

    var shortGermanHumanizer = humanizeDuration.humanizer({
        round: true,
        delimiter: ' ',
        units: ['h', 'm', 's'],
        language: 'shortDE',
        languages: {
            shortDE: {
                h: () => 'Std',
                m: () => 'Min',
                s: () => 'Sek'
            }
        }
    });
    let translations = {
        'product': '{__('product')}',
        'category': '{__('category')}',
        'manufacturer': '{__('manufacturer')}',
        'characteristic value': '{__('characteristic value')}',
        'variation': '{__('variation')}',
        'news': '{__('news')}',
    };

    $(() => updateStats());

    function updateStatsCB(data, item, type) {
        let stats = imageStats[type];
        stats.total += data.total;
        stats.corrupted += data.corrupted;
        stats.totalSize += data.totalSize;
        $(['xs', 'sm', 'md', 'lg', 'xl']).each(function (i, size) {
            stats.totalCached += data.generated[size];
        });

        if (typeof data.corruptedImagesList !== undefined && data.corruptedImagesList.length > 0) {
            $('#corrupted-images-wrap').removeClass('d-none');
            let tbody = $('#corrupted-images-tbody');
            data.corruptedImagesList.forEach(item => {
                if (item.hasOwnProperty('image')) {
                    tbody.append(
                        '<tr>'
                        + '<td class="col-xs-2">'
                        + translations[item.type]
                        + '</td>'
                        + '<td class="col-xs-8 word-break-all">'
                        + item.image
                        + '</td>'
                        + '<td class="col-xs-2">'
                        + '<a href="' + item.url + '">'
                        + item.identifier
                        + '</a></td></tr>'
                    );
                }
            });
        }

        if (data.finished === true) {
            var totalCached = 0;
            $('.item-total', item).text(stats.total);
            $('.item-corrupted', item).text(stats.corrupted);
            $('.item-total-size', item).text(formatSize(stats.totalSize));
            $('.item-generated', item).text(Math.round(stats.totalCached / 5, 0));
        } else {
            ioCall('loadStats', [type, data.nextIndex], (data) => updateStatsCB(data, item, type));
        }
    }

    function updateStats(typeToUpdate) {
        typeToUpdate = typeToUpdate || null;
        $('#cache-items tbody > tr').each(function (i, item) {
            let type = $(item).data('type');
            if (typeToUpdate !== null && typeToUpdate !== type) {
                return;
            }
            imageStats[type] = {
                total: 0,
                corrupted: 0,
                totalSize: 0,
                totalCached: 0
            };
            ioCall('loadStats', [type], function (data) {
                updateStatsCB(data, item, type);
            });
        });
    }

    $('[data-callback]').on('click', clickButton);

    function clickButton(e)
    {
        e.preventDefault();

        var $element = $(e.target);
        var callback = $element.data('callback');

        if ($element.attr('disabled') !== undefined) {
            return false;
        }

        if (!$element.attr('disabled')) {
            window[callback]($element);
        }
    }

    function cleanup(param)
    {
        var type = (typeof param.data('type') !== 'undefined') ? param.data('type') : 'product';
        running = true;
        lastResults = [];
        lastTick = new Date();
        notify = showCleanupNotify('{__('pendingImageCleanup')}', '{__('successImageDelete')}', type);
        $('.action-buttons a').attr('disabled', true);
        doCleanup(type, 0);
    }

    function stopCleanup()
    {
        running = false;
        $('.action-buttons a').attr('disabled', false);
    }

    function finishCleanup(result)
    {
        stopCleanup();

        notify.update({
            progress: 100,
            message: result.deletedImages + ' {__('successImageDelete')}',
            type: 'success',
            title: '{__('successImageCleanup')}'
        });
    }

    function doCleanup(type, index)
    {
        lastTick = new Date().getTime();
        ioCall('cleanupStorage', [type, index], function (result) {
            var items = result.deletes,
                deleted = result.deletedImages,
                total = result.total,
                offsetTick = new Date().getTime() - lastTick,
                perItem = Math.floor(offsetTick / result.checkedFiles),
                avg,
                remaining,
                eta,
                readable,
                percent;
            if (lastResults.length >= 10) {
                lastResults.splice(0, 1);
            }
            lastResults.push(perItem);
            avg = average(lastResults);
            remaining = total - result.checkedFilesTotal;
            eta = Math.max(0, Math.ceil(remaining * avg));
            readable = shortGermanHumanizer(eta);
            percent = Math.round(result.checkedFilesTotal / total * 100, 0);
            notify.update({
                message: '<div class="row">'
                    + '<div class="col-sm-4"><strong>' + percent + '</strong>%</div>'
                    + '<div class="col-sm-4 text-center">' + result.checkedFilesTotal + ' / ' + total + '</div>'
                    + '<div class="col-sm-4 text-right">' + readable + '</div>'
                    + '</div>',
                progress: percent
            });

            if (result.nextIndex >= total) {
                finishCleanup(result);
                return;
            }

            if (result.nextIndex > 0 && result.nextIndex < total && running) {
                doCleanup(type, result.nextIndex);
            }
        }, undefined, undefined, true);
    }

    function generate(param)
    {
        startGenerate((typeof param.data('type') !== 'undefined') ? param.data('type') : 'product');
    }

    function flush(param)
    {
        var type = (typeof param.data('type') !== 'undefined') ? param.data('type') : 'product';
        return ioCall('clearImageCache', [type, true], function (result) {
            updateStats(type);
            showFlushNotify(result.msg, '', type).update({
                progress: 100,
                message: '&nbsp;',
                type: result.ok == true ? 'success' : 'danger',
                title: result.msg
            });
        }, undefined, undefined, true);
    }

    function startGenerate(type)
    {
        running = true;
        lastResults = [];
        lastTick = new Date();
        notify = showGenerateNotify('{__('pendingImageGenerate')}', '{__('pendingStatisticCalc')}', type);

        $('.action-buttons a').attr('disabled', true);
        doGenerate(type, 0);
    }

    function stopGenerate()
    {
        running = false;
        $('.action-buttons a').attr('disabled', false);
    }

    function finishGenerate(type)
    {
        type = type || null;
        stopGenerate();
        updateStats(type);

        notify.update({
            progress: 100,
            message: '&nbsp;',
            type: 'success',
            title: '{__('successImageGenerate')}'
        });
        window.setTimeout(() => notify.close(), 5000);
    }

    function doGenerate(type, index)
    {
        lastTick = new Date().getTime();

        var call = loadGenerate(type, index, function (result) {
            if (result.lastRenderError) {
                updateStats(type);
                createNotify({
                    title: '{__('errorImageGenerate')}',
                    message: result.lastRenderError,
                }, {
                    type: 'danger',
                    timer: 10000
                });
            }

            let items = result.images,
                rendered = result.renderedImages,
                nextIndex = result.nextIndex,
                total = result.total,
                offsetTick = new Date().getTime() - lastTick,
                perItem = Math.floor(offsetTick / items.length),
                avg,
                remaining,
                eta,
                readable,
                percent;

            if (lastResults.length >= 10) {
                lastResults.splice(0, 1);
            }
            lastResults.push(perItem);

            avg = average(lastResults);
            remaining = total - rendered;
            eta = Math.max(0, Math.ceil(remaining * avg));
            readable = shortGermanHumanizer(eta);
            percent = Math.round(rendered * 100 / total, 0);

            notify.update({
                message: '<div class="row">'
                    + '<div class="col-sm-4"><strong>' + percent + '</strong>%</div>'
                    + '<div class="col-sm-4 text-center">' + rendered + ' / ' + total + '</div>'
                    + '<div class="col-sm-4 text-right">' + readable + '</div>'
                    + '</div>',
                progress: percent
            });

            if (rendered >= total) {
                finishGenerate(type);
                return;
            }

            if (rendered < total && running) {
                doGenerate(type, nextIndex);
            }
        });
        $.when(call).done();
    }

    function average(array)
    {
        var t = 0,
            i = 0;
        while (i < array.length) t += array[i++];
        return t / array.length;
    }

    function loadGenerate(type, index, callback)
    {
        return ioCall('generateImageCache', [type, index], function(result) {
            callback(result);
        }, undefined, undefined, true);
    }

    function showFlushNotify(title, message, type)
    {
        return createNotify({
            title: title,
            message: message
        }, {
            allow_dismiss: true,
            showProgressbar: true,
            timer: 5000
        });
    }

    function showCleanupNotify(title, message, type)
    {
        return createNotify({
            title: title,
            message: message
        }, {
            allow_dismiss: true,
            showProgressbar: true,
            timer: 5000,
            onClose: function () {
                stopCleanup();
            }
        });
    }

    function showGenerateNotify(title, message, type)
    {
        return createNotify({
            title: title,
            message: message
        }, {
            allow_dismiss: true,
            showProgressbar: true,
            delay: 0,
            timer: 5000,
            onClose: function () {
                stopGenerate();
                updateStats(type);
            }
        });
    }
</script>
{include file='tpl_inc/footer.tpl'}
