import CodeMirror from 'codemirror';
import 'codemirror/addon/hint/show-hint';
import 'codemirror/addon/hint/sql-hint';
import 'codemirror/addon/merge/merge';
import 'codemirror/addon/scroll/simplescrollbars';
import 'codemirror/addon/display/fullscreen';
import 'codemirror/mode/css/css';
import 'codemirror/mode/javascript/javascript';
import 'codemirror/mode/xml/xml';
import 'codemirror/mode/php/php';
import 'codemirror/mode/htmlmixed/htmlmixed';
import 'codemirror/mode/sass/sass';
import 'codemirror/mode/smarty/smarty';
import './codemirror-smartymixed';
import 'codemirror/mode/sql/sql';

window.CodeMirror = CodeMirror;
