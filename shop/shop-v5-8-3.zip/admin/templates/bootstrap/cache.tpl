{include file='tpl_inc/header.tpl'}
{include file='tpl_inc/cache_uebersicht.tpl'}
{include file='tpl_inc/footer.tpl'}
