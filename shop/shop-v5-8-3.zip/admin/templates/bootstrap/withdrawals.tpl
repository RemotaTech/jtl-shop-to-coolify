{include file='tpl_inc/header.tpl'}
{include file='tpl_inc/seite_header.tpl' cTitel=__('withdrawals') cBeschreibung=__('withdrawalsDesc')}
<div id="content">
    <div class="card">
        <div class="card-body">
            {include file='tpl_inc/filtertools.tpl' oFilter=$oFilter}
            {if isset($withdrawals) && count($withdrawals) > 0}
                {include file='tpl_inc/pagination.tpl' pagination=$pagination}
                <div>
                    <div class="subheading1">{__('withdrawals')}</div>
                    <hr class="mb-3">
                    <form method="post" action="{$adminURL}{$route}">
                        {$jtl_token}
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th class="check"></th>
                                        <th class="text-left">{__('withdrawalId')}</th>
                                        <th class="text-left">{__('orderNumber')}</th>
                                        <th class="text-left">{__('customerName')}</th>
                                        <th class="text-left">{__('email')}</th>
                                        <th class="th-4 text-center">{__('dateCreated')}</th>
                                        <th class="th-5 text-center">{__('mailStatus')}</th>
                                        <th class="th-6 text-center">{__('actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {foreach $withdrawals as $withdrawal}
                                        <tr>
                                            <td class="check">
                                                <div class="custom-control custom-checkbox">
                                                    <input class="custom-control-input" type="checkbox" name="selected[]" id="withdrawal-{$withdrawal->kWiderruf}" value="{$withdrawal->kWiderruf}">
                                                    <label class="custom-control-label" for="withdrawal-{$withdrawal->kWiderruf}"></label>
                                                </div>
                                            </td>
                                            <td>{$withdrawal->kWiderruf}</td>
                                            <td>{$withdrawal->cBestellnr}</td>
                                            <td>{$withdrawal->cName|escape:'html'}</td>
                                            <td><a href="mailto:{$withdrawal->cMail}">{$withdrawal->cMail|escape:'html'}</a></td>
                                            <td class="text-center">{$withdrawal->dErstellt|date_format:'d.m.Y H:i'}</td>
                                            <td class="text-center">
                                                {if $withdrawal->nMailStatus == 0}
                                                    <span class="badge badge-secondary">{__('mailStatusPending')}</span>
                                                {elseif $withdrawal->nMailStatus == 1}
                                                     <span class="badge badge-success">{__('mailStatusSent')}</span>
                                                {elseif $withdrawal->nMailStatus == 2}
                                                    <span class="badge badge-danger" {if $withdrawal->cMailError}data-toggle="tooltip" title="{$withdrawal->cMailError|escape:'html'}"{/if}>{__('mailStatusFailed')}</span>
                                                {/if}
                                            </td>
                                            <td class="text-center">
                                                <div class="btn-group">
                                                    {if $withdrawal->cKommentar}
                                                        <button type="button" 
                                                                class="btn btn-link px-2"
                                                                data-toggle="modal" 
                                                                data-target="#commentModal-{$withdrawal->kWiderruf}"
                                                                title="{__('showComment')}">
                                                            <span class="icon-hover">
                                                                <span class="fal fa-comment-alt"></span>
                                                                <span class="fas fa-comment-alt"></span>
                                                            </span>
                                                        </button>
                                                    {/if}
                                                    <a href="{$adminURL}{$route}?del={$withdrawal->kWiderruf}&token={$smarty.session.jtl_token}"
                                                       class="btn btn-link px-2 delete-confirm"
                                                       data-modal-body="{sprintf(__('confirmDelete'), $withdrawal->kWiderruf)}"
                                                       data-toggle="tooltip"
                                                       title="{__('delete')}">
                                                        <span class="icon-hover">
                                                            <span class="fal fa-trash-alt"></span>
                                                            <span class="fas fa-trash-alt"></span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        {if $withdrawal->cKommentar}
                                            <div class="modal fade" id="commentModal-{$withdrawal->kWiderruf}" tabindex="-1" role="dialog" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">{__('comment')} - {__('withdrawalId')} {$withdrawal->kWiderruf}</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p><strong>{__('customerName')}:</strong> {$withdrawal->cName|escape:'html'}</p>
                                                            <p><strong>{__('orderNumber')}:</strong> {$withdrawal->cBestellnr}</p>
                                                            <hr>
                                                            <p>{$withdrawal->cKommentar|escape:'html'|nl2br}</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">{__('close')}</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        {/if}
                                    {/foreach}
                                </tbody>
                            </table>
                        </div>
                        <div class="save-wrapper">
                            <div class="row">
                                <div class="col-sm-6 col-xl-auto text-left">
                                    <div class="custom-control custom-checkbox">
                                        <input class="custom-control-input" type="checkbox" id="select-all-2" name="select-all" value=""
                                               onchange="selectAllItems(this, $(this).prop('checked'))">
                                        <label class="custom-control-label" for="select-all-2">{__('selectAll')}</label>
                                    </div>
                                </div>
                                <div class="ml-auto col-sm-6 col-xl-auto">
                                    <button name="action" value="deleteSelected" class="btn btn-danger btn-block">
                                        <i class="fas fa-trash-alt"></i> {__('deleteSelected')}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                    {include file='tpl_inc/pagination.tpl' pagination=$pagination isBottom=true}
                </div>
            {else}
                <div class="alert alert-info" role="alert">{__('noDataAvailable')}</div>
            {/if}
        </div>
    </div>
</div>
{include file='tpl_inc/footer.tpl'}
